document.addEventListener('DOMContentLoaded', function() {
    // Example: Add a simple hover effect for visual feedback
    const productItems = document.querySelectorAll('.product-item');

    productItems.forEach(item => {
        item.addEventListener('mouseover', function() {
            this.style.backgroundColor = '#f8f9fa'; // Light gray hover
            this.style.cursor = 'pointer';
        });

        item.addEventListener('mouseout', function() {
            this.style.backgroundColor = 'transparent'; // Revert background
        });
    });
});
// Placeholder JavaScript file (script-recommend.js)

document.addEventListener('DOMContentLoaded', function() {
    // 1. Log all product card clicks (for tracking/analytics)
    const productCards = document.querySelectorAll('.product-card');

    productCards.forEach(card => {
        card.addEventListener('click', function() {
            const description = this.querySelector('.description').textContent;
            console.log('User clicked on product:', description.trim());
          
        });
    });

});
// Minimal JavaScript for demonstration/interactivity, not required for the look
document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.service-card');

    cards.forEach(card => {
        card.addEventListener('click', function() {
            // Example action: Log the card's ID when clicked
            console.log('Card Clicked:', this.id);
            // You could redirect, open a modal, etc. here
            // alert('You clicked on ' + this.querySelector('.service-title').textContent);
        });
    });
});
document.querySelectorAll('.supplier-item').forEach(item => {
            item.addEventListener('click', (event) => {
                event.preventDefault(); // Prevent default link action (optional)
                const url = item.getAttribute('data-link');
                // In a real application, you would navigate here, e.g.:
                // window.location.href = `https://${url}`;
                console.log(`Navigating to: https://${url}`);
                alert(`Simulating navigation to: https://${url}`);
            });
        });
        // This file can be used for any interactive elements, analytics, 
// or custom logic you want to add to the footer.

document.addEventListener('DOMContentLoaded', function() {
    // Example: Add a click listener to all social media icons
    const socialIcons = document.querySelectorAll('.social-icon-circle');
    socialIcons.forEach(icon => {
        icon.addEventListener('click', function(e) {
            // e.preventDefault(); // Uncomment to stop the link from opening
            console.log('Social icon clicked:', this.href);
        });
    });
});
// page 2 computer and tech
document.addEventListener('DOMContentLoaded', function() {
    // 1. Logic for View Toggle buttons
    const viewToggles = document.querySelectorAll('.view-toggles .btn');
    const productGrid = document.querySelector('.product-grid');

    viewToggles.forEach(btn => {
        btn.addEventListener('click', function() {
            viewToggles.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            // Example: Change grid layout when list view is selected (if you implemented list view)
            if (this.querySelector('.bi-list-task')) {
                // If list view is clicked, you might change the Bootstrap column classes
                // productGrid.classList.remove('row-cols-md-3');
                // productGrid.classList.add('row-cols-md-1', 'list-view');
            } else {
                // If grid view is clicked
                // productGrid.classList.remove('row-cols-md-1', 'list-view');
                // productGrid.classList.add('row-cols-md-3');
            }
        });
    });

    // 2. Logic for removing active filter tags
    const closeButtons = document.querySelectorAll('.custom-badge .btn-close');
    closeButtons.forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            const badge = this.closest('.custom-badge');
            badge.remove();
            
            // In a real application, you would also trigger a product refresh/API call here
            console.log('Filter removed. Triggering product update...');
        });
    });

    // 3. Simple click handler for placeholder sections
    const placeholderSections = document.querySelectorAll('.filter-section h6');
    placeholderSections.forEach(title => {
        // Only apply to the ones with the arrow icon (Price range, Condition, etc.)
        if (title.nextElementSibling && title.nextElementSibling.classList.contains('bi-chevron-down')) {
            title.style.cursor = 'pointer';
            title.addEventListener('click', function() {
                // Toggle the arrow icon orientation and show/hide content if available
                const icon = this.querySelector('.bi-chevron-down');
                if (icon) {
                    icon.classList.toggle('bi-chevron-down');
                    icon.classList.toggle('bi-chevron-up');
                }
                // You would add code here to slideToggle the associated content
            });
        }
    });
});
// show pages section
document.addEventListener('DOMContentLoaded', function() {
    const dropdownItems = document.querySelectorAll('.dropdown-menu .dropdown-item');
    const dropdownButton = document.querySelector('.custom-dropdown');

    dropdownItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 1. Update the button text with the selected value
            const selectedText = this.textContent;
            dropdownButton.textContent = selectedText;

            // 2. Manage the 'active' state in the dropdown list
            // Remove 'active' from all items
            dropdownItems.forEach(i => i.classList.remove('active'));
            // Add 'active' to the clicked item
            this.classList.add('active');

            // 3. (Real application logic) Trigger an event or API call
            const resultsPerPage = selectedText.replace('Show ', '');
            console.log(`Results per page changed to: ${resultsPerPage}. Triggering data refresh...`);
        });
    });

    // Pagination logic (if needed): 
    // You would typically use JS here to detect a page link click, 
    // prevent default navigation, and load new data via AJAX.
});
document.addEventListener('DOMContentLoaded', function() {
        // --- Filter Placeholder Logic ---

        const applyPriceFilter = document.getElementById('applyPriceFilter');
        const minPriceInput = document.getElementById('minPrice');
        const maxPriceInput = document.getElementById('maxPrice');
        const checkboxes = document.querySelectorAll('.form-check-input[type="checkbox"]');
        const radioButtons = document.querySelectorAll('.form-check-input[type="radio"]');

        function updateFilters() {
            const activeBrands = Array.from(document.querySelectorAll('#brandsCollapse .form-check-input:checked')).map(cb => cb.value);
            const activeFeatures = Array.from(document.querySelectorAll('#featuresCollapse .form-check-input:checked')).map(cb => cb.value);
            const activeCondition = document.querySelector('input[name="conditionRadio"]:checked').value;
            const minPrice = minPriceInput.value;
            const maxPrice = maxPriceInput.value;

            console.log('--- Filters Applied ---');
            console.log('Brands:', activeBrands);
            console.log('Features:', activeFeatures);
            console.log('Condition:', activeCondition);
            console.log('Price Range:', `$${minPrice} - $${maxPrice}`);
            // In a real application, you would send this data to the server via an AJAX request
            // to fetch the filtered products.
        }

        // Listeners for checkbox and radio button changes
        checkboxes.forEach(cb => {
            cb.addEventListener('change', updateFilters);
        });

        radioButtons.forEach(rb => {
            rb.addEventListener('change', updateFilters);
        });

        // Listener for the Apply Price button
        applyPriceFilter.addEventListener('click', function(e) {
            e.preventDefault();
            updateFilters();
            alert(`Filtering by price: $${minPriceInput.value} - $${maxPriceInput.value}`);
        });

        // Initial update
        updateFilters();
    });
    // page 4 
    document.addEventListener('DOMContentLoaded', () => {
    const itemCards = document.querySelectorAll('.custom-cart-item-card');
    const subtotalEl = document.getElementById('summary-subtotal');
    const totalEl = document.getElementById('summary-total');
    const discountValue = 60.00; // Fixed discount from the image
    const taxRate = 0.01; // 1% tax rate (to get $14.00 from $1400 subtotal)

    // Function to calculate the subtotal of all items
    function calculateSubtotal() {
        let subtotal = 0;
        
        itemCards.forEach(card => {
            // Get price from the item-price element
            const priceText = card.querySelector('.item-price').textContent;
            const price = parseFloat(priceText.replace('$', ''));

            // Get selected quantity
            const qtySelect = card.querySelector('.form-select');
            const quantity = parseInt(qtySelect.value);

            // Add to subtotal
            subtotal += price * quantity;
        });

        return subtotal;
    }

    // Function to update the summary panel
    function updateSummary() {
        const newSubtotal = calculateSubtotal();
        const taxAmount = newSubtotal * taxRate;
        const newTotal = newSubtotal - discountValue + taxAmount;

        // Update the display elements
        subtotalEl.textContent = `$${newSubtotal.toFixed(2)}`;
        // Note: Tax and Total elements rely on fixed numbers from the image, 
        // a real app would update tax too. For simplicity:
        totalEl.textContent = `$${newTotal.toFixed(2)}`;
    }

    // Event listeners for quantity changes
    itemCards.forEach(card => {
        const qtySelect = card.querySelector('.form-select');
        // When the quantity changes, recalculate the summary
        qtySelect.addEventListener('change', updateSummary);
    });

    // Initial calculation on page load
    updateSummary(); 
    
    // Add event listener for 'Remove' and 'Save for later'
    document.querySelectorAll('.remove-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            if(confirm('Are you sure you want to remove this item?')) {
                // Remove the parent card from the DOM
                e.target.closest('.custom-cart-item-card').remove(); 
                // Recalculate summary after removal
                updateSummary();
            }
        });
    });
});
// page 5 clothes and wear
 function changeImage(el) {
        document.getElementById("mainImage").src = el.src;
        document.querySelectorAll('.thumbnail-img').forEach(img => img.classList.remove('active'));
        el.classList.add('active');
    }

